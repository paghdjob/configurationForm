import React from "react";

const Contact = (props) => {
  return <h1>Contact page</h1>;
};

export default Contact;
