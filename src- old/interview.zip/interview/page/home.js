import React from "react";

const Home = (props) => {
  return <h1>Home page</h1>;
};

export default Home;
