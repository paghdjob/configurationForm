import { createContext } from "react";
export const employeeObj = {
    // firstname: 'yogeshppp',
    // lastname:'paghdalppp'
}; 
const employeeContext = createContext();

export default employeeContext;